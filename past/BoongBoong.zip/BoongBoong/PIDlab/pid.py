from car import Car

class pid:
    def __init__(self):
        self.kd = 0
        self.ki = 0
        self.kp = 0
        self.errorsum = 0
        self.error = 0
        self.preerror = 0
        self.car = Car()

    def errorvalue:
        self.car.line_detector.

    def pid(self):
        value = (self.kp * error) + (self.ki * count) + (kd * (error - preerror)
         
    
